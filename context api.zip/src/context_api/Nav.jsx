import { useContext, useReducer } from "react"
import ContextApi from "./ContextApi"
function Nav () {
    let {setData} = useContext(ContextApi)
    function reducer (state, action) {
       switch (action.type) {
        case 'inc':
            return state + 1
            break;
        case 'dec':
            return state - 1
        default: state
            break;
       }

    }
    let  [state, dispatch] = useReducer(reducer,0)
    return(
        <>
         <button onClick={()=>{dispatch({type:'inc'})}}>increase</button>
         {state}
         <button onClick={()=>{dispatch({type:'dec'})}}>decrease</button>
        {/* <input type="search" onChange={(e)=>{setData(e.target.value)}} /> */}
        {/* <input type='search' onChange={(e)=>{dispatch({type: 'data', payload: e.target.value})}} /> */}
        <input type="search" onChange={(e)=>{dispatch({type: 'data',payload: e.target.value})}} />
        </>
    )
}
export default Nav
