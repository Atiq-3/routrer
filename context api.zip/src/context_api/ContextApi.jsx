import { createContext} from "react";
  
let ContextApi =  createContext()
export default ContextApi
    


