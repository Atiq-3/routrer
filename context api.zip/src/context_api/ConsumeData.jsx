import { useContext } from "react"
import ContextApi from "./ContextApi"
import Provider from "./Provider"
function ConsumeData () {
    // let {setData} = useContext (ContextApi)
    // console.log(setData, "data inside consumeData")
    let {state} = useContext(ContextApi)
    console.log(state,"consume data inside state ")
    return (
        <>
        <h1>Consumer</h1>
        {state}
        </>
    )
}
export default ConsumeData