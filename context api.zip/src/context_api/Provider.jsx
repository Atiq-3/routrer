import { useReducer, useState } from "react"
import ContextApi from "./ContextApi"
function Provider (props) {
      function reducer () {
        if (action.type == 'data') {
            return action.payload
        }
        return(
            <>
            </>
        )
      }
    // let [Data,setData] = useState("")
    // console.log(Data , "data provider")
    let [state,dispatch] = useReducer(reducer,"sam")
    console.log(state,"state")
    return (
        <>
        
        <h1>Provider</h1>
        <ContextApi.Provider value = {{state,dispatch}}>
            {props.children}
        </ContextApi.Provider>
        </>
    )
}
export default Provider