import { BrowserRouter } from "react-router-dom"
// import CreateStore from "./context_api/ContextApi"
import Provider from "./context_api/Provider"
import ConsumeData from "./context_api/ConsumeData"
import Nav from "./context_api/Nav"

function App() {


  return (
    <>
      <BrowserRouter>
      <Provider>
        <ConsumeData/>
        <Nav/>
      </Provider>
      </BrowserRouter>
    </>
  )
}

export default App
