import { useState } from "react"
import "./app.css"
function FormValidation() {
    let [name, setname] = useState('')
    let [number, setnumber] = useState('')
    let [email, setemail] = useState('')
    let [password, setpassword] = useState('')
    let [ConfirmPassword, setConfirmPassword] = useState('')

    function submit(e) {
        e.preventDefault()
        console.log(name, number, email, password)

        if (name == '') {
            alert("please enter your name")
        }
        else if (number.length !== 10) {
            alert("please enter 10 digit number")
        } else if (!email.includes("@gmail.com")) {
            alert("please enter proper email with @gmail.com")
        } else if (password.length < 6) {
            alert("password should be atleast 6 characters long")
        } else if (password !== ConfirmPassword) {
            console.log("enter proper password")
        } 
        
        if (name == '' || number !== '' || email == '' || password == '' || ConfirmPassword == '' ) { 

            alert("please fill all details")
        }
       
    }



    return (
        <>
            <form>
                <div className="Parent" >
                    <div className="Child" >
                        <div className="middle">
                            <label >Name:</label><input type="text" onChange={(e) => { setname(e.target.value) }} /> <br />
                            <label>Number:</label> <input type="number" onChange={(e) => { setnumber(e.target.value) }} /><br />
                            <label>Email:</label> <input type="email" onChange={(e) => { setemail(e.target.value) }} /><br />
                            <label>Password:</label> <input type="password" onChange={(e) => { setpassword(e.target.value) }} /><br />
                            <label>Confrim Password:</label> <input type="password" onChange={(e) => { setConfirmPassword(e.target.value) }} /><br />
                            <button onClick={(e) => { submit(e) }}>submit</button>
                        </div>
                    </div>
                </div>
            </form>
    
    
        </>
    )
}



export default FormValidation