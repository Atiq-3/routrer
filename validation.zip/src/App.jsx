
import FormValidation from "./FormValidation"

function App() {
  

  return (
    <div>
      <FormValidation />
    </div>
  )
}

export default App
