import React from "react"
function  Error( ) {
    return (
        <>
        <div>Error</div>
        </>
    )
}
export default Error