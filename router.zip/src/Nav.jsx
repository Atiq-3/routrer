import React from "react";
import { Link } from "react-router-dom";
function Nav () {
   let Navdata= [
    {
        path : "./",
        element : "./Home"
    },
    {
        path : "./",
        element : "./About"
    },
    {
        path : "./",
        element : "./Contact"
    },
    {
        path : "./",
        element : "./Error"
    }
   ] 
   return (
    <>
    <ul>
        <li><Link to="./">Home</Link></li>
        <li><Link to="./About">About</Link></li>
        <li><Link to="./Contact">Contact</Link></li>
        <li><Link to="./Error">Error</Link></li>
    </ul>
    
    </>
   )
}
export default Nav