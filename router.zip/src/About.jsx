import React from "react"
function About () {
    return (
        <>
        <h2>hello</h2>
        <div>About</div>
        </>
    )
}
export default About