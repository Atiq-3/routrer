// import { useEffect, useState } from "react"

// function UseEffect() {

//     let [add, setadd] = useState('jai')
//     let [remove, setremove] = useState()

    // let [Count, setCount] = useState(0)
    // let [Data, setData] = useState(0)
    // Run only first time 
    // useEffect(() => {
    //     Sum()
    //     console.log("first UseEffect print")
    // })

    // function Sum() {
    //     console.log('inside sum is print')
    // }

    // Run on every Updated 

    // useEffect(() => {
    //    Update()
    // },[Count])

    // useEffect (()=>{
    //     Decrease()

    // },[Data])

    // function Update() {
    //    console.log('Updated one')
    // }

    // function Decrease ( ) {
    //     console.log('Decrease data')
    // }

    // Run On Unmount (Clean Up Function)

    //    useEffect(()=>{
    //     console.log('add data')
    //    },)

    //    useEffect(()=>{
    //     console.log('remove data')
    //    },[add])

       
    //   function Add () {
    //     localStorage.setItem("user","atiq")
    //     console.log('Add')
    //   }    
      

    //   function Remove () {
    //     localStorage.removeItem("user")
    //     console,log("remove ")
    //   }
//     return (
//         <div>
//             <button onClick={() => {setCount(Count+1) }}>Click me To Update</button>
//             <button onClick={() => { setData(Data-1)}}>Click me To Decrease</button>

//             <button onClick={() => {setadd(add+1) }}>Add Data</button>
//             <button onClick={() => { setremove(remove+1)}}>Remove data</button>
//         </div>
//     )
// }
// export default UseEffect