import { useEffect, useState } from "react"
import "../fetch-project/App.css"
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
function FakeStoreApi() {

    let [Getdata, setGetData] = useState([])
    useEffect(() => {
        let fetchdata = fetch("https://fakestoreapi.com/products")
            .then((firstStep) => {
                return firstStep.json()
            })
            .then((secondStep) => {
                setGetData(secondStep)
                console.log(secondStep, 'secondStep')
            })
    }, [])

    return (
        <div>
            <>
                <div className="d-flex .flex-nowrap flex-wrap justify-content-center ">
                {
                        Getdata.map((val) => {
                            return (
                                <>
                                    <Card style={{ width: '30rem' }}>
                                        <Card.Img variant="top" src={val.image} />
                                        <Card.Body>
                                            <Card.Title>{val.title}</Card.Title>
                                            <Card.Text>
                                            {val.description}
                                            </Card.Text>
                                            <Card.Text>
                                            {val.category}
                                            {val.price}
                                            </Card.Text>
                                            <Button variant="primary">Go somewhere</Button>
                                        </Card.Body>
                                    </Card>

                                </>
                            )
                        })
                    }
                </div>
                  

            </>
        </div>
    )

}
export default FakeStoreApi