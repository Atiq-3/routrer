import { useEffect, useState } from "react"
import Card from 'react-bootstrap/Card';
function Universities () {
           let [Getdata, setGetData] = useState([])
           useEffect(() => {
               let fetchdata = fetch("http://universities.hipolabs.com/search")
                   .then((firstStep) => {
                       return firstStep.json()
                   })
                   .then((secondStep) => {
                       setGetData(secondStep)
                       console.log(secondStep, 'secondStep')
                   })
           }, [])
       
           return (
               <div>
                   <>
                   <div className="d-flex .flex-nowrap flex-wrap justify-content-center">
                       {
                           Getdata.map((val) => {
                               return (
                                   <>
                                    <Card style={{ width: '18rem' }}>
                                        <Card.Body>
                                            <Card.Title>{val.name}</Card.Title>
                                            <Card.Subtitle className="mb-2 text-muted">{val.domains}</Card.Subtitle>
                                            <Card.Subtitle className="mb-2 text-muted">{val.country}</Card.Subtitle>
                                            <Card.Text>
                                            {val.alpha_two_code}
                                            </Card.Text>
                                        </Card.Body>
                                    </Card>
                                         
                                               {/* <a href={"http://www." + val.web_pages}>Website</a> */}
                                        
       
                                   </>
                               )
                           })
                       }
                      </div>
       
                   </>
               </div>
           )
   }

export default Universities