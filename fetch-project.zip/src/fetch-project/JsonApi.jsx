import { useEffect, useState } from "react"
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
function JsonApi () {
  let [Getdata, setGetData] = useState([])
         useEffect(() => {
             let fetchdata = fetch("https://jsonplaceholder.typicode.com/users")
                 .then((firstStep) => {
                     return firstStep.json()
                 })
                 .then((secondStep) => {
                     setGetData(secondStep)
                     console.log(secondStep, 'secondStep')
                 })
         }, [])
     
         return (
             <div>
                 <>
                 <div className="d-flex .flex-nowrap flex-wrap justify-content-space-evenly">
                     {
                         Getdata.map((val) => {
                             return (
                                 <>
                                       <Card style={{ width: '18rem' }}>
                                        <Card.Body>
                                            <Card.Title>{val.name}</Card.Title>
                                            <Card.Subtitle className="mb-2 text-muted">{val.username}</Card.Subtitle>
                                            <Card.Subtitle className="mb-2 text-muted">{val.phone}</Card.Subtitle>
                                            <Card.Subtitle className="mb-2 text-muted">{val.email}</Card.Subtitle>
                                            <Card.Subtitle className="mb-2 text-muted">{val.address.street}</Card.Subtitle>
                                        </Card.Body>
                                    </Card>


                                    
                                    <div   className="modal show" style={{ display: 'block', position: 'initial' }}>
{/*                                       
                                        <Modal.Dialog>
                                            <Modal.Header closeButton>
                                                <Modal.Title>Modal title</Modal.Title>
                                            </Modal.Header>

                                            <Modal.Body>
                                                <p>Modal body text goes here.</p>
                                            </Modal.Body>

                                            <Modal.Footer>
                                                <Button variant="secondary">Close</Button>
                                                <Button variant="primary">Save changes</Button>
                                            </Modal.Footer>
                                        </Modal.Dialog> */}
                                    </div>
                                    
                        
                                 </>
                             )
                         })
                     }
     
                 </div>
                 </>
             </div>
         )
}
export default JsonApi