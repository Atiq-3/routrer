import { useEffect, useState } from "react"
import Card from 'react-bootstrap/Card';
function ImageApi() {
    let [Getdata, setGetData] = useState([])
    useEffect(() => {
        let fetchdata = fetch("https://dog.ceo/api/breeds/image/random")
            .then((firstStep) => {
                return firstStep.json()
            })
            .then((secondStep) => {
                setGetData(secondStep)
                console.log(secondStep, 'secondStep')


            })

    }, [])
    let fdata = [{ ...Getdata }]


    return (
        <div>
            <>
                <div className="d-flex justify-content-center">
                    {
                        fdata.map((val) => {
                            return (
                                <>
                                    <Card style={{ width: '40rem' }}>
                                        <Card.Img variant="top" src={val.message} />
                                        <Card.Body>
                                            <Card.Title>{val.message}</Card.Title>
                                        </Card.Body>
                                    </Card>
                                </>
                            )
                        })
                    }
                </div>

            </>
        </div>
    )
}
export default ImageApi