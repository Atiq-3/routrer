import { useEffect, useState } from "react"
import Card from 'react-bootstrap/Card';
function JsonPlaceHolder() {
    let [Getdata, setGetData] = useState([])
    useEffect(() => {
        let fetchdata = fetch("https://jsonplaceholder.typicode.com/posts")
            .then((firstStep) => {
                return firstStep.json()
            })
            .then((secondStep) => {
                setGetData(secondStep)
                console.log(secondStep, 'secondStep')
            })
    }, [])

    return (
        <div>
            <>
                <div className="d-flex .flex-nowrap flex-wrap justify-content-center">
                    {
                        Getdata.map((val) => {
                            return (
                                <>
                                    <Card style={{ width: '18rem' }}>
                                        <Card.Body>
                                            <Card.Title>{val.title}</Card.Title>
                                            <Card.Subtitle className="mb-2 text-muted">{val.body}</Card.Subtitle>
                                            <Card.Text>
                                            
                                            </Card.Text>
                                        </Card.Body>
                                    </Card>
                                    
                                </>
                            )
                        })
                    }
                </div>

            </>
        </div>
    )
}
export default JsonPlaceHolder