// import UseEffect from "./component/UseEffect"
import FakeStoreApi from "./fetch-project/FakeStoreApi"
// import FetchData from "./fetch-project/FetchData"
import Home from "./fetch-project/Home"
import ImageApi from "./fetch-project/ImageApi"
import JsonApi from "./fetch-project/JsonApi"
import JsonPlaceHolder from "./fetch-project/JsonPlaceHolder"
import Universities from "./fetch-project/Universities"
import { BrowserRouter , Routes, Route } from "react-router-dom"

function App() {

  return (
    <div>
      {/* <FetchData/> */}
      <BrowserRouter>
        <Home/>
        <Routes>
        <Route path='/home' element={<Home />} >
            <Route path='/home/fakestoreapi' element={<FakeStoreApi />} />
            <Route path='/home/jsonplaceholder' element={<JsonPlaceHolder />} />
            <Route path='/home/universities' element={<Universities />} />
            <Route path='/home/imageapi' element={<ImageApi/>} />
            <Route path='/home/jsonapi' element={<JsonApi />} />
          </Route>
        </Routes>
      </BrowserRouter>
      
    {/* <UseEffect/> */}
    </div>
  )
}

export default App
