// import { useEffect, useState } from "react"

// function FetchData () {
//       let[Getdata,setGetData] = useState([])
//       useEffect(()=>{
//        let fetchdata =  fetch ("https://jsonplaceholder.typicode.com/posts")
//        .then((firstStep)=>{
//          return firstStep.json()
//        })
//        .then((secondStep)=>{
//           setGetData(secondStep)
//           console.log(secondStep,'secondStep')  
//        })
//       },[])

//       return (
//         <div>
//           <>
         
//           {
//             Getdata.map((val)=>{
//                 return (<>
                
//                 <div>{val.id}</div>
//                 <div>{val.title}</div>
//                 <div>{val.body}</div>

//                 </>
//                 )
//             })
//           }
          
          
//           </>
//         </div>
//       )
// }
// export default FetchData