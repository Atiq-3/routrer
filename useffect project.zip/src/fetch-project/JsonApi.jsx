import { useEffect, useState } from "react"
function JsonApi () {
  let [Getdata, setGetData] = useState([])
         useEffect(() => {
             let fetchdata = fetch("https://jsonplaceholder.typicode.com/users")
                 .then((firstStep) => {
                     return firstStep.json()
                 })
                 .then((secondStep) => {
                     setGetData(secondStep)
                     console.log(secondStep, 'secondStep')
                 })
         }, [])
     
         return (
             <div>
                 <>
     
                     {
                         Getdata.map((val) => {
                             return (
                                 <>
                                     <div className="Parent">
                                         <div className="Child">
                                             <div>{val.name}</div>
                                             <div>{val.username}</div>
                                             <div>{val.phone}</div>
                                             <div>{val.email}</div>
                                             <div>{val.phone}</div>
                                         </div>
     
                                     </div>
     
     
                                 </>
                             )
                         })
                     }
     
     
                 </>
             </div>
         )
}
export default JsonApi