import { useEffect, useState } from "react"
 function JsonPlaceHolder () {
        let [Getdata, setGetData] = useState([])
        useEffect(() => {
            let fetchdata = fetch("https://jsonplaceholder.typicode.com/posts")
                .then((firstStep) => {
                    return firstStep.json()
                })
                .then((secondStep) => {
                    setGetData(secondStep)
                    console.log(secondStep, 'secondStep')
                })
        }, [])
    
        return (
            <div>
                <>
    
                    {
                        Getdata.map((val) => {
                            return (
                                <>
                                    <div className="Parent">
                                        <div className="Child">
                                            <div>{val.body}</div>
                                            <div>{val.title}</div>
                                        </div>
    
                                    </div>
    
    
                                </>
                            )
                        })
                    }
    
    
                </>
            </div>
        )
}
export default JsonPlaceHolder