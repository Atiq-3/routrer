import { useEffect, useState } from "react"
import "../fetch-project/App.css"
function FakeStoreApi() {

    let [Getdata, setGetData] = useState([])
    useEffect(() => {
        let fetchdata = fetch("https://fakestoreapi.com/products")
            .then((firstStep) => {
                return firstStep.json()
            })
            .then((secondStep) => {
                setGetData(secondStep)
                console.log(secondStep, 'secondStep')
            })
    }, [])

    return (
        <div>
            <>

                {
                    Getdata.map((val) => {
                        return (
                            <>
                                <div className="Parent">
                                    <div className="Child">
                                        <div>{val.category}</div>
                                        <div>{val.description}</div>
                                        <div>{val.image}</div>
                                        <div>{val.price}</div>
                                        <div>{val.title}</div>
                                    </div>

                                </div>


                            </>
                        )
                    })
                }


            </>
        </div>
    )

}
export default FakeStoreApi