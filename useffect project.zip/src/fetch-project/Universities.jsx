import { useEffect, useState } from "react"
function Universities () {
           let [Getdata, setGetData] = useState([])
           useEffect(() => {
               let fetchdata = fetch("http://universities.hipolabs.com/search")
                   .then((firstStep) => {
                       return firstStep.json()
                   })
                   .then((secondStep) => {
                       setGetData(secondStep)
                       console.log(secondStep, 'secondStep')
                   })
           }, [])
       
           return (
               <div>
                   <>
       
                       {
                           Getdata.map((val) => {
                               return (
                                   <>
                                       <div className="Parent">
                                           <div className="Child">
                                               <div>{val.alpha_two_code}</div>
                                               <div>{val.country}</div>
                                               <div>{val.domains}</div>
                                               <div>{val.name}</div>
                                               <div>{val.web_pages}</div>
                                           </div>
       
                                       </div>
       
       
                                   </>
                               )
                           })
                       }
       
       
                   </>
               </div>
           )
   }

export default Universities