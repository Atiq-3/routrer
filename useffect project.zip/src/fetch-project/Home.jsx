import { Link, Outlet } from "react-router-dom"

function Home () {
    return (
        <div>
            <>
             <ul>
             <li><Link to="/">home</Link></li> 
               <li><Link to="/home/fakestoreapi">Fakestoreapi</Link></li> 
               <li><Link to="/home/jsonplaceholder">Jsonplaaceholder</Link></li> 
               <li><Link to="/home/universities">universities</Link></li> 
               <li><Link to="/home/imageapi">imageApi</Link></li> 
               <li><Link to="/home/jsonapi">Jsonapi</Link></li> 
             </ul>
             <Outlet></Outlet>
            </>    
        </div>
    )
}
export default Home