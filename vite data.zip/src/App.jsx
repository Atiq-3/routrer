import { BrowserRouter, Route, Routes } from "react-router-dom"
import NavigationProduct from "./Component/NavigationProduct"
import ProductDescription from "./Component/ProductDescription"
function App() {


  return (
    <>
    <BrowserRouter>
       <Routes>
        <Route path="/" element={<NavigationProduct/>}/>
        <Route path='/value/:id'element={<ProductDescription/>}/>

      </Routes>  
    </BrowserRouter>
    {/* <NavigationProduct/> */}
    </>
  )
}

export default App
