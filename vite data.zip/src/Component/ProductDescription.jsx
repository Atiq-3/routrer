import { useParams } from "react-router-dom"
import { Product } from "./Product"
function ProductDescription () {
    console.log(Product,"product")
     let param = useParams()
     console.log(param,'param')
      
      let FilterData = Product.filter((val)=>{
        return val.id == param.id
    })
    console.log(FilterData,'FilterData')
    return(
        <div>
            <h1>Product Description </h1>
            {
                FilterData.map((val)=>{
                    <h2>{val.name}</h2>,
                    <h3>{val.category}</h3>    
            
                })
            }
        </div>
    )
}
export default ProductDescription