import { Link, useNavigate } from "react-router-dom";
import { Product } from "./Product";
import "../Component/prod.css"
function NavigationProduct () {
       let navigated = useNavigate()
    //    console.log(navigated)
    //    console.log(Product,'Product')
    
    return (
        <div>
           <h1>Products</h1>
           <div className="Box">
            {
                Product.map((val)=>{
                 let pp=`value/${val.id}`
                    return (
                        <>
                         <Link to={pp}>
                         <div className='cart' >
                                <h2>{val.name}</h2>
                                <p>{val.category}</p>
                                <p>{val.description}</p>
                                <h2>{val.price}</h2>
                                <button onClick={()=>{sendData(val)}}>Description </button>
                            </div>
                         
                         </Link>
                        </>
                    )
                })
            }

           </div>
        </div>
    )
}
export default NavigationProduct