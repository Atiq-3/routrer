import React from "react"
function WhatsApp () {
    return (
        <div>
        whatsapp
        </div>
    )
}
export default WhatsApp