import React from "react"
function Mail () {
    return (
        <div>
          mails
        </div>
    )
}
export default Mail