import React from "react"
function Call () {
    return (
        <div>
        Call
        </div>
    )
}
export default Call