import { Link,Outlet } from "react-router-dom"
import React from "react"
function Help () {
    return (
        <div>
          <h1>Help</h1>
          <ul>
            <li><Link to='/help/call'>call</Link></li>
            <li><Link to='/help/mail'>Mail</Link></li>
            <li><Link to='/help/whatsapp'>whatsapp</Link></li>
          </ul>
          <Outlet></Outlet>
        </div>

    )
}
export default Help