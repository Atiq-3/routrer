import { BrowserRouter , Routes, Route } from "react-router-dom"
import Call from "./NestingRouter/Call"
import Mail from "./NestingRouter/Mail"
import WhatsApp from "./NestingRouter/WhatsApp"
import Help from "./NestingRouter/Help"
import Dynamic from "./DynamicRouting/Dynamic"

function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
        <Route path='/helpdynamic/:type' element={<Dynamic />} />
        <Route path='/help' element={<Help />} >
            <Route path='/help/call' element={<Call />} />
            <Route path='/help/message' element={<Mail />} />
            <Route path='/help/mail' element={<WhatsApp />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App
