import { BrowserRouter, Routes,Route } from "react-router-dom"
// import Home from "./Component/Home"
import FormFetch from "./Component/FormsFetch"
function App() {

  return (
    <div>
       <FormFetch/>
      {/* <BrowserRouter>
         <Home/>
         <FormFetch/>
          <Routes>
            <Route path = "/" element = {<Home/>} />
            <Route path = "/home/formfetch" element = {<FormFetch/>} />
          </Routes>
      </BrowserRouter> */}
    </div>
  )
}

export default App
