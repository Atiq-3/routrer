import { useEffect, useState } from "react"
function FormFetch () {
    let [fname,setfname] = useState()
    let [Lastname,setLastName] = useState()
    let [Nummber,setNumber] = useState()
    let [Email,setEmail] = useState()
    let [Password,setPassword] = useState()
    let [ConfirmPassword,setConfirmPassword] = useState()
    let [Data,setData] = useState()

    function SubmitBtn (e) {
      e.preventDefault()
      setData({fname,Lastname,Email,Nummber,Password,ConfirmPassword})
    }

    function getData () {
      fetch ("http://localhost:4000/users")
      .then((Firstdata)=>{
         return Firstdata.json()
      })
      .then((secondData)=>{
         console.log(secondData,"second data")
      })
    }
     useEffect (()=>{
        getData()
     },[])
     
     function SendData () {
      let obj= {
        method: "post",
        headers: {
            "Content-Type" : "application/json",
            "Accept" : "application/json"
        },
        body: JSON.stringify(Data)
    }
      fetch ("http://localhost:4000/users",obj)
      .then((Firstdata)=>{
         return Firstdata.json()
      })
      .then((secondData)=>{
         console.log(secondData,"second data")
      })
      getData()
     }
     useEffect (()=>{
        setData()
     },[Data])
     console.log (Data,"data of useeffect")

     return (
     <div>
         <h1>Form Registertation</h1>
         <label>Name<input type="text"  onChange={(e)=>{setfname(e.target.value)}} placeholder="Enter your First Name"/></label>
         <label>Last Name<input type="text"  onChange={(e)=>{setLastName(e.target.value)}} placeholder="Enter your First Name"/></label>
         <label>Number<input type="number"  onChange={(e)=>{setNumber(e.target.value)}} placeholder="Enter your First Name"/></label>
         <label>Email<input type="email"  onChange={(e)=>{setEmail(e.target.value)}} placeholder="Enter your First Name"/></label>
         <label>Password<input type="password"  onChange={(e)=>{setPassword(e.target.value)}} placeholder="Enter your First Name"/></label>
         <label>Confirm Password<input type="password"  onChange={(e)=>{setConfirmPassword(e.target.value)}} placeholder="Enter your First Name"/></label>
         <button onClick={(e)=>{SubmitBtn(e)}}>Submit</button>
     </div>
   )

}
export default FormFetch
