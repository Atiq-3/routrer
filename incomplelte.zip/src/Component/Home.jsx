// import { Link, Outlet } from "react-router-dom"
// function Home() {
//     return (

//         <div>   
//             <Link to="/"></Link>
//             <h1><Link to="/home/formfetch"></Link>Form Registertation</h1>
//             <Outlet></Outlet>
//         </div>


//     )

// }
// export default Home