import { useParams } from "react-router-dom"
import axios from "axios"
import { useEffect, useState } from "react"
import "./Desc.css"
function Description() {
    let params = useParams()
    let [data, setData] = useState([])
    let id = params.id
    let [image, setImage] = useState("")
    let [count ,setCount] = useState(1)
    useEffect(() => {
        axios.get(`http://localhost:4000/Product/${id}`)
            .then((firstData) => {
                console.log(firstData.data, "second data")
                setData([firstData.data])
            })
    }, [])
    return (
        <>
            <div>
                {
                    data.map((val) => {
                        return (
                            <>
                                <div className='mainContainer'>
                                    <div className='imgContainer'>
                                        <div className='mainImg'>
                                            <img src={image} alt="" />
                                        </div>
                                        <div className='downImage'>
                                            <div className='sImg' onMouseOver={() => { setImage(val.image[0]) }}>
                                                <img src={val.image[0]} alt="" />
                                            </div>
                                            <div className='sImg' onMouseOver={() => { setImage(val.image[1]) }}>
                                                <img src={val.image[1]} alt="" />
                                            </div>
                                            <div className='sImg' onMouseOver={() => { setImage(val.image[2]) }}>
                                                <img src={val.image[2]} alt="" />
                                            </div>
                                            <div className='sImg' onMouseOver={() => { setImage(val.image[3]) }}>
                                                <img src={val.image[3]} alt="" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className='descContainer'>
                                        <h1>{val.name}</h1>
                                        <h2>{val.description}</h2>
                                        <h3>{val.price * count}</h3>
                                        <button onClick={() => { setCount(count + 1) }}>+</button>
                                        {count}
                                        <button onClick={() => { setCount(count - 1) }}>-</button>
                                        <button >Add to cart</button>
                                    </div>
                                </div>


                                {/* <div className="parentdiv">
                                    <div className="maindiv">
                                        <div className="partonediv">
                                            <div className="imgone"><img src={val.image[0]} alt="" />
                                                <div className="imgtwo"><img src={val.image[1]} alt="" /></div>
                                                <div className="imgthree"><img src={val.image[2]} alt="" /></div>
                                                <div className="imgfour"><img src={val.image[3]} alt="" /></div>
                                            </div>
                                        </div>
                                        <div className="parttwodiv">
                                            <h1>{val.name}</h1>
                                            <h4>{val.description}</h4>
                                            <h4>{val.price}</h4>
                                        </div>
                                    </div>
                                </div> */}
                                {/* <img src={val.image[0]} alt="" />
                                <h1></h1>
                                <h2></h2>
                                <h3></h3> */}
                            </>
                        )
                    })
                }
            </div>
        </>
    )
}
export default Description