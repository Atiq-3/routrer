import { useState } from "react"
import createStore from "./CreateStore"

function Provider ({children}) {
    let [Data,setData] = useState("")
    console.log(Data,"data")
    return(
        <>
        <createStore.Provider value={{Data,setData}}>
            {children}
        </createStore.Provider>
        </>
    )
}
export default Provider