
import { createContext } from "react";

let createStore = createContext()
export default createStore