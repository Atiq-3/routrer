import { useContext, useEffect, useState } from "react"
import createStore from "./ContextApi/CreateStore"
import "./Nav.css"
import axios from "axios"
import { useLocation } from "react-router-dom"

function Navbar() {
    let { setData, data } = useContext(createStore)
    console.log(setData,'setdata')
    let [nav, setnav] = useState([])
    let { pathname } = useLocation()
    console.log(setData, "setdata")
    useEffect(() => {
        axios.get("http://localhost:4000/Product")
            .then((firstData) => {
                console.log(firstData.data, "second data")
                setnav([firstData.data])
            })
    }, [])
    function showSearchBox(e) {
        if (pathname == 'productdesc/1') {
            setData(e.target.value)
            document.getElementById('pp').style.display = 'block'
        }
        else {
            setData(e.target.value)
            document.getElementById('pp').style.display = "none"
        }
    }

    return (
        <>

            <div className="box">
                <h1>nav</h1>
                <input className="nav" type="search" onChange={(e) => { showSearchBox(e) }} />
            </div>
            {
                data != "" ?
                    <div className="container" id="pp">
                          {
                                nav.map((val) => {
                                    console.log(val,"val")
                                    return (
                                        <>
                                            <p>{val.name}</p>
                                        </>
                                    )
                                })
                            }
                        <div className="middle" id="dd">
                          
                        </div>
                    </div> : ""
            }

        </>
    )

}
export default Navbar