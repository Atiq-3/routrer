import axios from "axios"
import { useContext, useEffect, useState } from "react"
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import "./Product.css"
import { Link } from "react-router-dom";
import createStore from "./ContextApi/CreateStore";


function Product() {
    let [apiData, setApiData] = useState([])
    let {Data} = useContext (createStore)
    let [filterData,setFilterData] = useState([])
    console.log(Data,"product page data")
    useEffect(() => {
        axios.get("http://localhost:4000/Product")
            .then((firstData) => {
                // console.log(firstData.data, "data fetch from api")
                setApiData(firstData.data)
                setFilterData(firstData.data)
                // console.log(setApiData,"apidata")
            })
    }, [])
    
    useEffect(()=>{
        let filterData = apiData.filter((val)=>{
            return val.name.toLowerCase().includes(Data.toLowerCase())
         })
         console.log(filterData,"filterdata")
        //  setApiData(filterData)
         setFilterData(filterData)

    },[Data])

    // useEffect(()=>{
    //     let filterData = apiData.filter((val)=>{
    //       return val.name.toLowerCase().includes(data.toLowerCase())
    //     })
    //     console.log(filterData,"filterData")
    //     setApiData(filterData)
    //     setFilterData(filterData)
    //   },[data])
    return (
        <div>
            <div className="heading"><h1>Products</h1></div>
            <div className="flex-container">
            {
                filterData.map((val) => {
                    let descriptionId = `productdesc/${val.id}`
                    return (
                        <Link to={descriptionId}>
                        <>   <div className="custom-card">
                                <Card  style={{ width: '18rem' }}>
                                    <Card.Img className="custom img" variant="top" src={val.image[0]} />
                                    <Card.Body className="body">
                                        <Card.Title className="texts">{val.name}</Card.Title>
                                        <Card.Text className="text">
                                            {val.description}
                                        </Card.Text>
                                        <Button className="btn" variant="primary">More Details</Button>
                                    </Card.Body>
                                </Card>
                            </div>
                        </>
                            </Link>
                    )
                })
            }
            </div>
        </div>
    )
}
export default Product
{/* <div className="parentBox">
    <div className="childBox">
        
            <div className="childTwo">
                <img src={val.image[0]} alt="" />
                <h1>{val.name}</h1>
                <h2>{val.description}</h2>
                <h4>{val.price}</h4>
            </div>
        
    </div>
</div> */}