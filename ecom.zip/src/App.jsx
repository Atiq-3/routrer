import { BrowserRouter,Routes ,Route } from "react-router-dom"
import Product from "./Product"
import Description from "./Description"
import Provider from "./ContextApi/Provider"
import Navbar from "./Navbar"


function App() {
 

  return (
    <>
     <BrowserRouter>
       <Provider>
        <Navbar/>
        <Routes>
          <Route path = "/" element = {<Product/>} />  
          <Route path = "/productdesc/:id" element = {<Description/>}/>
        </Routes >
        </Provider>  
     </BrowserRouter>
    </>
  )
}

export default App
